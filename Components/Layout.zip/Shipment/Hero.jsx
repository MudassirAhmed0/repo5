import styles from '../../styles/Chalja.module.css';
// import bannerImg from '../../assets'

const Hero = () => {
  return (
    <section className={styles.shipmentHero}>
        <span className={styles.shipmentHeroImg}>
                {/* <Image src={}/> */}
        </span>
    </section>
  )
}

export default Hero